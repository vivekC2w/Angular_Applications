import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batch-list',
  template: `<h2>Inside BatchList Component : Child1</h2>
 
  <ul *ngFor = "let value of Batches">
    <li>{{value.Name}}</li>  
  </ul>
  `
})
export class BatchListComponent implements OnInit {
  
  public Batches = [
    {"Name" : "PPA", "Duration" : 4, "Fees" : 16500},
    {"Name" : "LB", "Duration" : 3, "Fees" : 17000},
    {"Name" : "PYTHON", "Duration" : 2, "Fees" : 15000}
  ];


  constructor() { }

  ngOnInit(): void {
  }

}
