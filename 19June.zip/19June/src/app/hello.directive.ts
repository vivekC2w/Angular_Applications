import { Directive } from '@angular/core';

import { ElementRef } from '@angular/core';
import { HostListener } from '@angular/core';

@Directive({
  selector: '[appHello]'
})
export class HelloDirective 
{

  constructor(private _eObj:ElementRef) { }

  @HostListener('mouseenter')onmouseenter()
  {
    this._eObj.nativeElement.style.background='yellow';
  }

  @HostListener('mouseleave')onmouseleave()
  {
    this._eObj.nativeElement.style.background='blue';
  }
  //Logic

}
