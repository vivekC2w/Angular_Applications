var Ret:number = 0;

//Regular Function
function Addition1(No1:number, No2:number):number
{
    var Ans:number = 0;
    Ans = No1 + No2;
    return Ans;
}

Ret = Addition1(10, 11);
console.log("Addition is: "+Ret);

