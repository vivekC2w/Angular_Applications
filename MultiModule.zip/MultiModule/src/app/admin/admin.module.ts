import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AcompComponent } from './acomp/acomp.component';
import { ScompComponent } from '../student/scomp/scomp.component';


@NgModule({
  declarations: [
    AcompComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule
  ],
  exports:[
    AcompComponent
  ]
})
export class AdminModule { }
