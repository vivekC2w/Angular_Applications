import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AcompComponent } from './acomp/acomp.component';

const routes: Routes = [
  {path:'',component:AcompComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
