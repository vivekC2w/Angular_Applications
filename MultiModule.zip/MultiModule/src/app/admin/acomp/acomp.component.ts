import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acomp',
  templateUrl: './acomp.component.html',
  styleUrls: ['./acomp.component.css']
})
export class AcompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
