import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudentRoutingModule } from './student-routing.module';
import { ScompComponent } from './scomp/scomp.component';


@NgModule({
  declarations: [
    ScompComponent
  ],
  imports: [
    CommonModule,
    StudentRoutingModule
  ],
  exports: [
    ScompComponent
  ]
})
export class StudentModule { }
